<?php $__env->startSection('contents'); ?>
  <?= app('\Spatie\BladeJavaScript\Renderer')->render('route_root', '/'.env('ADMIN_ROUTE_PREFIX')); ?>

  <div ng-view></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>