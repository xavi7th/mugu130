<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
	<head>
		<meta charset="utf-8">
    <title><?php echo e(env('APP_NAME')); ?> - <?php echo $__env->yieldContent('title'); ?></title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>" />
		<link rel="apple-touch-icon" href="/apple-touch-icon.png">
    
    <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>">
		<?php echo $__env->yieldContent('customCSS'); ?>

    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->


	</head>

	<body ng-app="dashboard" ng-strict-di>
    <base href="/" target="_self">

		

			<?php echo $__env->yieldContent('contents'); ?>


	    
	  </div>


		<!-- Scripts -->

    <script src="<?php echo e(asset(mix('/js/manifest.js'))); ?>" charset="utf-8"></script>
    <script src="<?php echo e(asset(mix('/js/vendor.js'))); ?>" charset="utf-8"></script>
    <script src="<?php echo e(asset(mix('/js/app.js'))); ?>" charset="utf-8"></script>
		<script src="<?php echo e(asset(mix('/js/libraries.js'))); ?>" charset="utf-8"></script>
		<script src="<?php echo e(asset(mix('/js/dashboard-app.js'))); ?>" charset="utf-8"></script>

		<?php echo $__env->yieldContent('customJS'); ?>

	</body>
</html>
