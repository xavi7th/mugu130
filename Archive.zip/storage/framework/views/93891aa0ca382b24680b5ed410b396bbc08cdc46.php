<?php $__env->startSection('contents'); ?>
  <?= app('\Spatie\BladeJavaScript\Renderer')->render('errors', $errors); ?>

  <div ng-view></div>

  <input type="text" ng-model="kuh" name="" value=""> {{ kuh }}
  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>