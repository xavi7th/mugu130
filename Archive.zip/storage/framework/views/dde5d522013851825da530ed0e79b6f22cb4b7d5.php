<style media="screen">
  #main-controller{
    min-height: 100vh;
      position: relative;
      background-color: #135482;
      background-image: url(/img/4.jpg);
      background-blend-mode: exclusion;
      background-repeat: no-repeat;
      background-size: cover;
  }
</style>


<?php $__env->startSection('contents'); ?>

      <section id="intro">
        <div class="grid-container">
          <div class="grid-70 push-15">

            <div id="form" class="ui segments">
              <div class="ui segment">
                <h2 class="ui center aligned icon header dash_header">
                  <i class="circular users icon"></i>
                  Account Suspended
                </h2>
                <div class="ui error message">
                    
                    <div class="header">
                      Dear <?php echo e(Auth::user()->firstname); ?>, your account has been suspended by the admin for violation of our terms and conditions. To resolve the pending issue, you can take the following steps
                    </div>
                    <br>
                    <ul class="list">
                      <li>Send the admin a message using the form below</li>
                      <li>Make sure to include "Account Suspended" in the subject of your message</li>
                      <li>After that an admin will contact you with the stepd required to activate your account</li>
                    </ul>
                  </div>
              </div>

              <div class="ui segment" style="padding-bottom: 30px;">
                <div class="ui tab active" data-tab="register">
                  <form class="ui form" method="POST" action="<?php echo e(route('contact')); ?>">

                    <?php if(count($errors) > 0): ?>
                      <div class="ui error message">
                        <div class="header">
                          There were some errors with your submission
                        </div>
                        <ul class="list">
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                      </div>
                    <?php endif; ?>

                    <?php if(session()->has('success')): ?>

                      <div class="ui floating info icon message">
                        <i class="close icon"></i>
                         <i class="inbox icon"></i>
                        <div class="header center aligned">
                          <?php echo e(session('success')); ?>

                        </div>
                      </div>
                    <?php endif; ?>
                    <?php echo e(csrf_field()); ?>

                    <div class="field">
                      <input type="text" name="subject" placeholder="Enter Subject" required value="<?php echo e(old('subject')); ?>">
                    </div>
                    <div class="field">
                      <textarea name="message" rows="5" cols="80" placeholder="Enter Message"><?php echo e(old('message')); ?></textarea>
                    </div>
                    <button type="submit" style="background-color: #135482;" class="ui fluid orange button">Send message</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      


      <section id="mid">
        <div class="grid-container">
          <div class="grid-30">
            
          </div>
          <div class="grid-50">
            
          </div>
        </div>
      </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJS'); ?>
  <script type="text/javascript">
  $('.message .close')
    .on('click', function() {
      $(this)
        .closest('.message')
        .transition('fade')
      ;
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.others', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>