<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaystackWebhook extends Model
{
    protected $guarded = [];
    // protected $hidden = ['correct_option'];
    // protected $dates = ['deleted_at'];
}
