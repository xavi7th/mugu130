<template lang="html">
  <footer class="">
    <div class="grid-container ">
      <div class="grid-100">
        <div class="ui right floated celled horizontal list">
          <a class="item" target="_self" href="#">© 2018 FastPlay24 &amp; Tcom </a> <span class="deg">·</span>
          <a class="item" target="_blank" href="/terms-and-conditions">Terms</a> <span class="deg">·</span>
          <a class="item" target="_blank" href="/privacy">Privacy</a> <span class="deg">·</span>
          <a class="item" target="_self" href="/frequently-asked-questions">Help &amp; FAQs</a> <span class="deg">·</span>
          <a class="item" target="_self" href="support-center">Support</a> <span class="deg">·</span>
          <a class="item" target="_self" href="/calculator">Calculator</a>
        </div>
        <div class="ui celled horizontal list">
          <a class="item" href="https://www.facebook.com/fastplay24/" target="_blank">Facebook</a> <span class="deg">·</span>
          <a class="item" href="https://www.twitter.com/fastplay24/" target="_blank">Twitter</a> <span class="deg">·</span>
          <a class="item" href="https://www.instagram.com/fastplay24/" target="_blank">Instagram</a>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
