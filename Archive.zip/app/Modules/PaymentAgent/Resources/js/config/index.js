export default {
  phone: '0700 123 0123',
  whatsapp: '+23408022212260',
  placeholderImage: '/static/img/default-image.jpg',
  defaultAvatar: 'static/img/avatars/default.jpg'
}
