<?php return array (
  'providers' => 
  array (
    0 => 'App\\Modules\\PaymentAgent\\Providers\\PaymentAgentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'App\\Modules\\PaymentAgent\\Providers\\PaymentAgentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);