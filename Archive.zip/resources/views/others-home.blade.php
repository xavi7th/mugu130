@extends('layouts.app')

@section('contents')

      <div ng-view></div>

@endsection
