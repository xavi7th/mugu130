<title>Page not found | {{ env('APP_NAME') }}</title>
<meta name="robots" content="noindex,nofollow">

<meta itemprop="name" content="404error">

<meta name="theme-color" content="{{ env('APP_THEME_COLOR') }}">
<meta name="apple-mobile-web-app-status-bar-style" content="{{ env('APP_THEME_COLOR') }}">
