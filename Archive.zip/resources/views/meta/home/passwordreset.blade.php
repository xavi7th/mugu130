<title>Password Reset | {{ env('APP_NAME') }}</title>
<meta name="robots" content="noindex,nofollow">

<meta name="description" content="Reset your password"/>
<meta name="author" content="{{ env('APP_AUTHOR') }}">
<meta name="abstract" content="Reset your password"/>

<meta property="fb:admins" content="jovworie" />
<meta property="fb:app_id" content="171894576842093" />

<meta itemprop="name" content="Password Reset">
<link itemprop="url" href="{{ route('password.request') }}">
