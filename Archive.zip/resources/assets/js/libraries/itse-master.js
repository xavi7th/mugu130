$(document).ready(function(){
  $('#dropdown').dropdown();

  $('#dropdown2').dropdown();

  $('#dropdown-2').dropdown();
  $('#dropdown-3').dropdown();

  $('#session-menu .item').tab();
  $('#profile-menu .item').tab();
  $('#post-menu .item').tab();
  $('#edit .item').tab();

});
