@extends('layouts.dashboard')

@section('contents')


  <div ng-view></div>

@endsection
