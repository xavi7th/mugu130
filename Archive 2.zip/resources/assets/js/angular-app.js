  require('angular');
  require('angular-route');


  home = angular.module('home', ['ngRoute']);


  // require('./angular/routes/home-routes');

  // require('./angular/controllers/home-controller');
