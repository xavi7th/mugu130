<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
    ),
  ),
  'jenssegers/agent' => 
  array (
    'providers' => 
    array (
      0 => 'Jenssegers\\Agent\\AgentServiceProvider',
    ),
    'aliases' => 
    array (
      'Agent' => 'Jenssegers\\Agent\\Facades\\Agent',
    ),
  ),
  'intervention/validation' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Validation\\ValidationServiceProvider',
    ),
  ),
  'matriphe/imageupload' => 
  array (
    'providers' => 
    array (
      0 => 'Matriphe\\Imageupload\\ImageuploadServiceProvider',
    ),
    'aliases' => 
    array (
      'Imageupload' => 'Matriphe\\Imageupload\\ImageuploadFacade',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'spatie/laravel-blade-javascript' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\BladeJavaScript\\BladeJavaScriptServiceProvider',
    ),
  ),
);